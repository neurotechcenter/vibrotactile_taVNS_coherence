function [intraNC, interNC, newmat] = vibrotactile_taVNS_chkboard (cormat, clustlen)

newmat = cormat;
for cl = 1:length(clustlen) 
    
    if cl == 1
        intraind = 1:clustlen(cl);
    else
        intraind = sum(clustlen(1:cl-1))+1:sum(clustlen(1:cl));
    end
    
    % intranetwork 
    intraNCtemp= cormat(intraind, intraind);
    intraNC.dat = intraNCtemp(find(triu(intraNCtemp, 1)));
    intraNC.mean(cl) = mean(intraNC.dat,'omitnan');
    intraNC.sd(cl) = nanstd(intraNC.dat);
    
    % internetwork
    
    for ncl = cl:length(clustlen)
        
        interNC.dat = [cormat(intraind, sum(clustlen(1:ncl-1))+1:sum(clustlen(1:ncl-1)) + clustlen(ncl))];   
        interNC.mean(cl,ncl) = mean(interNC.dat(:),'omitnan');
        interNC.sd(cl,ncl) = nanstd(interNC.dat(:));

        % identify triu indices from the orig matrix
        f_ind_mat = zeros(size(cormat));
        f_ind_mat(intraind, sum(clustlen(1:ncl-1))+1:sum(clustlen(1:ncl-1)) + clustlen(ncl)) = 2;

        inter_ind = find(triu(f_ind_mat,1) == 2);
        newmat(inter_ind) = interNC.mean(cl,ncl);

    end
    
    f_ind_mat(intraind, intraind) = 1;
    intra_ind = find(triu(f_ind_mat,1) == 1);
    newmat(intra_ind) = intraNC.mean(cl);
    
end
    