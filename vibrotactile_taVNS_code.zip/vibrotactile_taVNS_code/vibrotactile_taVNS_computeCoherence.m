% 3/2/23 - Kara Donovan

function [coherence] = vibrotactile_taVNS_computeCoherence(signal,lLim,uLim,numChans,trials,sr,newSR,ws,pOverlap,lp_flag)
% signal should be formatted as channels x samples x trials
% lLim and uLim are the bounds of the frequency window for which you want to compute coherence 
% sr is original sampling rate, newSR is what you want to downsample to
% ws is window size for mscohere function, pOverlap is % overlap for mscohere function
% lp_flag = 1 if lowpass filter is needed, otherwise set to 0

parfor t = 1:trials
    if lp_flag == 1
        % add an anti-aliasing filter before downsampling (i.e., lowpass filter at 200 Hz)
        lp_cutoff = 200;
        order = 5;
        type = 'low';
        [b0_lp, a0_lp] = butter(order, 2*lp_cutoff/sr, type);
        lp_signal = filtfilt(b0_lp,a0_lp,double(signal(:,:,t)'))'; % note: have to be in samples x chans for filtfilt function
        % downsample lowpass-filtered data
        downSampledData = downsample(lp_signal',sr/newSR)';
    else
        % downsample data as is
        downSampledData = downsample(signal(:,:,t)',sr/newSR)';
    end
    
    ind = 0;
    temp = NaN(numChans*(numChans-1)/2,length(lLim:uLim));
    for i = 1:(numChans-1)
        if isnan(downSampledData(i,1))
            ind = ind + length((i+1):numChans);
            continue
        end
        for j = (i+1):numChans
            if isnan(downSampledData(j,1))
                ind = ind + 1;
                continue
            end
            ind = ind + 1;
            [temp(ind,:),~] = mscohere(downSampledData(i,:),downSampledData(j,:),ws,pOverlap*ws,lLim:uLim,newSR);
        end
    end
    coherence{t,1} = temp;
end

end