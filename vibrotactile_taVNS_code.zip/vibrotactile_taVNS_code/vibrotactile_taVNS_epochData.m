function [epochedData] = vibrotactile_taVNS_epochData(signal,stimulusCodes,stimulusConditions,timebefore,timeafter,samplingrate)

% signal 
% for timebefore and timeafter, scale to seconds
% for stimulusCodes, this function will treat all non-zero values as
% different conditions
% stimulusConditions should be a struct equal to the number of non-zero
% stimulus codes, and is organized in assending order: ie each field
% should correspond with each non-zero stimulus code

waitBar = waitbar(0,'Epoching Data');

uniqueStimuli = unique(stimulusCodes,'sorted');
uniqueStimuli(uniqueStimuli == 0) = [];
epochedData = struct;

for i = 1:length(uniqueStimuli)

    code = uniqueStimuli(i);
    tempStimulusCodes = stimulusCodes;
    tempStimulusCodes(find(tempStimulusCodes ~= code)) = 0;
    tempStimulusCodes(find(tempStimulusCodes == code)) = 1;
    trialStartStop = diff(double(tempStimulusCodes));
    startIndex = find(trialStartStop == 1);
    
    waitbar(i/length(uniqueStimuli),waitBar,['Epoching:' stimulusConditions{i}])
    for ch = 1:size(signal,1)
        for trial = 1:length(startIndex)
            preTrial = startIndex(trial)-(timebefore*samplingrate);
            postTrial = startIndex(trial)+(timeafter*samplingrate);
            if preTrial < 1
                continue
            end
            temp3DMatrix(ch,:,trial) = signal(ch,preTrial:postTrial);
        end
    end

    epochedData.(stimulusConditions{i}) = temp3DMatrix;
    
    clear tempStimulusCodes

end

close(waitBar)

end


