% Kara Donovan: 5/9/2023
% group analysis on coherence
% function dependencies: vibrotactile_taVNS_plotChordDiagram

clear;
clc;

vibrationFreqs = {'Two Hz','Six Hz','Twelve Hz','Twenty Hz','Forty Hz'};
lLim = 4; uLim = 8;
freqName = 'Theta';

colors = [66, 134, 137; 44, 78, 113; 181, 106, 84; 214, 139, 82; 157, 93, 129; 112, 70, 120; 0 105 54]./255;

%% count how many subjects are included
numSubj = dir(fullfile(['coherenceData/regionAverages/','*' num2str(lLim) '-' num2str(uLim) '*_v2.mat']));
fieldName = 'mean';
allLabels = cell(1,length(numSubj));
allPercentRespPairs = NaN(length(vibrationFreqs),length(numSubj));
baseIntraNCMeans = cell(1,length(numSubj));
baseInterNCMeans = cell(1,length(numSubj));

for subj = 1:length(numSubj)
    
    load(fullfile(numSubj(subj).folder, numSubj(subj).name));
    allLabels{1,subj} = uniqueLabels;
    
    numCells = numel(intraNCAllFreq);
    if subj == 1
        allIntraNCMeans = cell(numCells,length(numSubj));
        allInterNCMeans = cell(numCells,length(numSubj));
    end
    
    % stim
    for i = 1:numCells
        currentIntraStruct = intraNCAllFreq{i};
        currentIntraMean = currentIntraStruct.(fieldName);
        allIntraNCMeans{i,subj} = currentIntraMean;
        currentInterStruct = interNCAllFreq{i};
        currentInterMean = currentInterStruct.(fieldName);
        allInterNCMeans{i,subj} = currentInterMean;
    end
    
    % baseline
    baseIntraNCMeans{1,subj} = intraNC_base.(fieldName);
    baseInterNCMeans{1,subj} = interNC_base.(fieldName);
    
    % store percent of responder pairs for each subject
    allPercentRespPairs(:,subj) = percentRespPairs;
    
    clear intraNCAllFreq interNCAllFreq newmatAllFreq intraNC_base interNC_base newmat_base uniqueLabels percentRespPairs   
end

%% plot distributions of baseline coherence for each subject
figure();
for s = 1:length(numSubj)
    [~,~,baseData{1,s}] = find(baseInterNCMeans{1,s});
end
baseCohereMeans = cellfun(@(x) mean(x,'omitnan'), baseData);
baseCohereStd = cellfun(@(x) std(x,'omitnan')/sqrt(length(x)), baseData);
bar(baseCohereMeans,'FaceColor',colors(7,:)); hold on; box off
errorbar(1:length(numSubj),baseCohereMeans, baseCohereStd,'k','linewidth',1,'linestyle','none')
    
% graph aesthetics
ylim([0 0.6]); yticks([0 0.2 0.4 0.6])
xlabel('Subject'); ylabel('Baseline Coherence')
ax = gca; ax.FontSize = 10;

% graph size
set(gcf,'Position',[400 300 700 500])
saveas(gcf,['figures/coherence/baseline_' freqName '_coherence_xSubj.svg'])

%% concatenate baseData to run kruskal-wallis test
mergedBaseData = vertcat(baseData{:});
% create grouping variable
subjLabel = arrayfun(@(i) repmat(i, size(baseData{i}, 1), 1), 1:numel(baseData), 'UniformOutput', false);
subjLabel = vertcat(subjLabel{:});
[pBase,tblBase,statsBase] = kruskalwallis(mergedBaseData,subjLabel,'off');
cBase = multcompare(statsBase,"CType","bonferroni");
tblMultComp = array2table(cBase,"VariableNames", ...
    ["Group A","Group B","Lower Limit","A-B","Upper Limit","P-value"]);

%% grouped bar chart showing percent of responder pairs for each subject
% Number of groups (number of columns)
numGroups = size(allPercentRespPairs, 2);
% Number of bars in each group (number of rows)
numBars = size(allPercentRespPairs, 1);
% Create a figure
figure;
% Plot grouped bar chart
b = bar(allPercentRespPairs'); box off
% customize colors
for i = 1:size(allPercentRespPairs,1)
    b(i).FaceColor = colors(i,:);
end
% Set labels and title
ylabel('Responder Pairs (% of Total Pairs)');
ylim([0 100])
% Create a legend
legend('2 Hz', '6 Hz', '12 Hz', '20 Hz', '40 Hz'); legend box off
% Specify group labels
groupLabels = {'Subj001', 'Subj002', 'Subj003', 'Subj004', 'Subj005', 'Subj006', 'Subj007'};
% Set x-axis tick labels
xticklabels(groupLabels);
set(gca,'FontSize',12)
title([freqName ' Coherence Responders'],'FontSize',14);
set(gcf,'Position',[50 100 900 300])
saveas(gcf,['figures/coherence/percentRespPairsCoherence_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])

%% compute SNR for percent responder pairs
meanPercentResp = mean(allPercentRespPairs,2);
stdPercentResp = std(allPercentRespPairs,0,2);
SNR_PercentResp = meanPercentResp./stdPercentResp;

% rank in descending order
[~ , sortedSNR] = sort(SNR_PercentResp, 'descend');
% plot in descending order
positionOrder = NaN(size(sortedSNR));
for i = 1:length(sortedSNR)
    positionOrder(i) = find(sortedSNR == i);
end

% plot
figure();
scatter(positionOrder, SNR_PercentResp, 120, colors(1:5,:), 'filled')
xlim([0 6]); ylim([1.5 3])
labels_SNR = {'2 Hz','6 Hz','12 Hz','20 Hz','40 Hz'};
labels_SNR_sort = labels_SNR(sortedSNR);
labels_buffer = cell(1,7);
labels_buffer(2:6) = labels_SNR_sort;
xticklabels(labels_buffer);
ylabel('SNR')
set(gca,'FontSize',12)
set(gcf,'Position',[50 100 250 300])
saveas(gcf,['figures/coherence/SNR_percentRespPairsCoherence_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])

%% scatter plot of individual points at each frequency
% Define the number of conditions and points per condition
numConditions = size(allPercentRespPairs, 1); % Number of rows (conditions)
numPoints = size(allPercentRespPairs, 2);    % Number of columns (values per condition)

% Create x-values for straight lines
xValues = repelem(1:numConditions, numPoints); % Repeat each condition number 7 times

% Flatten the data
flatData = allPercentRespPairs';
flatData = flatData(:);

% Repeat the colors for each point in the row
flatColors = repelem(colors(1:numConditions, :), numPoints, 1);

% Scatter plot
figure();
scatter(xValues, flatData, 120, flatColors, '.');

% aesthetics
xlim([0 6]); xticks(1:5); xticklabels(labels_SNR)
ylim([0 60]); yticks(0:20:60); yticklabels({'1.5','2','2.5','3'}); ylabel('SNR') % matching figure size from above
set(gca,'FontSize',12)
set(gcf,'Position',[50 100 250 300])
saveas(gcf,['figures/coherence/subjVar_percentRespPairsCoherence_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])

%% plotting regional coherence averages for individual subjects
numFreq = size(allInterNCMeans,1);

% store the average global coherence change for each subject and each frequency
avgCoherenceChange = NaN(length(numSubj),numFreq);
coherenceInc = NaN(length(numSubj),numFreq);

for subj = 1:length(numSubj)
    figure();
    for freq = 1:numFreq
        subplot(2,3,freq)
        % Flip values to the lower triangle
        matrix = allInterNCMeans{freq, subj};
        matrix = matrix + matrix.' - diag(diag(matrix));
        % Plot the lower triangle
        matrixLower = tril(matrix);
        % Replace NaN values with zero
        matrixLower(isnan(matrixLower)) = 0;
        % Compute average coherence change
        nonzeroValues = matrixLower(matrixLower ~= 0);
        avgCoherenceChange(subj,freq) = mean(nonzeroValues);
        % Count how many pairs show a coherence increase of at least 0.05
        coherenceInc(subj,freq) = sum(matrixLower(:) > 0.05);
        % set upper triangle to NaN
        matrixLower(matrixLower == 0) = NaN;
        imagescHandle = imagesc(matrixLower, [-0.08, 0.08]);
        % Set transparency for NaN values
        set(imagescHandle, 'AlphaData', ~isnan(matrixLower));
        axis square; box off
        ax = gca; % Get the current axes
        set(ax, 'Color', 'w'); % Set the background color to white
        colormap(brewermap([],'*RdBu')); c = colorbar;
        % Adjust tick positions to surround the boxes
        nBoxes = length(allLabels{1,subj});
        xticks(0.5:1:nBoxes+0.5); % Set ticks at the edges of the boxes
        yticks(0.5:1:nBoxes+0.5);
        % Add labels at the midpoints between edges
        xticklabels(['', allLabels{1,subj}, '']); % Add an empty string to handle outer edges
        yticklabels(['', allLabels{1,subj}, '']);
        cLabel = ylabel(c,'MSC (Baseline Subtraction)'); set(cLabel,'Rotation',270,'FontSize',10); cLabel.Position(1) = 3.5;
        title(vibrationFreqs(freq))
    end
    set(gcf,'Position',[50 100 1500 800])
    subjName = groupLabels{subj};
    sgtitle(subjName)
    saveas(gcf,['figures/coherence/' subjName '_anatomicalGroupsAvgCoherence_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])
end

%% identify common regions across all subjects
commonRegions = intersect(allLabels{1}, allLabels{2});
for i = 3:numel(allLabels)
    commonRegions = intersect(commonRegions, allLabels{i});
end

%% identify frequency of each region
allElements = vertcat(allLabels{:});
[uniqueElements, ~, idx] = unique(allElements);
counts = histcounts(idx, numel(uniqueElements));

% combine regions and counts into a table
regionFreq = table(counts',uniqueElements,'VariableNames',{'Counts','Regions'});
% sort table based on counts in descending order
sortedRegionFreq = sortrows(regionFreq,'Counts','descend');

% plot in order of most frequent anatomical regions to least
figure();
bar(sortedRegionFreq.Counts,0.6,'FaceColor',[44 78 113]./255)
box off
ylim([0 8]); ylabel('Number of Subjects with Coverage','FontSize',12)
xticks(1:length(uniqueElements)); xticklabels(sortedRegionFreq.Regions)
ax = gca; ax.FontSize = 12;
title('Frequency of Electrode Coverage Across Anatomical Regions','FontSize',16)
set(gcf,'Position',[50 100 1450 500])
saveas(gcf,'figures/methods/frequencyAnatomicalCoverage_v2.svg')

%% pool together coherence matrices for all subjects
% find where the changeover from left to right occurs
% extract the first character of each string
firstChar = cellfun(@(s) s(1), uniqueElements);

% Find the unique first characters
uniqueFirstChar = unique(firstChar);

% right hemisphere
rightHem = find(firstChar == 'R');
rightHem = rightHem(1);

figure();
groupAvgCoherencePlot = NaN(length(uniqueElements),length(uniqueElements),length(vibrationFreqs));
for freq = 1:length(vibrationFreqs)
    groupAvgCoherence = NaN(length(uniqueElements),length(uniqueElements),length(numSubj));
    for roiIdx = 1:length(uniqueElements)
        roi = uniqueElements{roiIdx};

        for s = 1:length(numSubj)
            % check if roi exists for the given subject
            [isInCellArray, roiIndex] = ismember(roi, allLabels{1,s});
            % if roi does not exist, move to next iteration
            if ~isInCellArray
                continue
            end

            for r = 1:length(uniqueElements)
                % identify element at given index
                curElement = uniqueElements{r};
                % check if current element exists for the given subject
                [isInCellArray, curIndex] = ismember(curElement, allLabels{1,s});
                % if current element does not exist, move to next iteration
                if ~isInCellArray
                    continue
                else
                    % pull out the coherence value for roi & current element
                    if curIndex < roiIndex
                        groupAvgCoherence(r,roiIdx,s) = allInterNCMeans{freq,s}(curIndex,roiIndex);
                    else
                        groupAvgCoherence(r,roiIdx,s) = allInterNCMeans{freq,s}(roiIndex,curIndex);
                    end
                end  
            end
        end
    end
    subplot(2,3,freq)
    groupAvgCoherencePlot(:,:,freq) = mean(groupAvgCoherence,3,'omitnan');
    interim = groupAvgCoherencePlot(:,:,freq);
    interim(isnan(interim)) = 0;
    groupAvgCoherencePlot(:,:,freq) = interim;
    % only plot lower triangle
    matrixLowerGroup = tril(groupAvgCoherencePlot(:,:,freq));
    % replace zeros with NaNs
    matrixLowerGroup(matrixLowerGroup == 0) = NaN;
    % plot coherence matrix
    imagescHandleGroup = imagesc(matrixLowerGroup, [-0.05, 0.05]);
    % Set transparency for NaN values
    set(imagescHandleGroup, 'AlphaData', ~isnan(matrixLowerGroup));
    axis square; box off; hold on
    ax = gca; % Get the current axes
    set(ax, 'Color', 'w'); % Set the background color to white      
    colormap(brewermap([],'*RdBu')); c = colorbar;  
    % plot aesthetics
    nBoxesGroup = length(uniqueElements);
    xticks(0.5:1:nBoxesGroup + 0.5); % Set ticks at the edges of the boxes
    yticks(0.5:1:nBoxesGroup + 0.5);
    % Add labels at the midpoints between edges
    xticklabels(['', uniqueElements, '']); % Add an empty string to handle outer edges
    yticklabels(['', uniqueElements, '']);
    cLabel = ylabel(c,'MSC (Baseline Subtraction)'); set(cLabel,'Rotation',270,'FontSize',10); cLabel.Position(1) = 3.5;
    title(vibrationFreqs(freq))
end
set(gcf,'Position',[50 100 1500 800])
sgtitle(['Group Average ' freqName ' Coherence Changes'])
saveas(gcf,['figures/coherence/GroupAvgCoherenceAllRegions_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])

%% aggregate group avg coherence distributions
groupAvgCoherenceDist = NaN(353,length(vibrationFreqs));

for freq = 1:length(vibrationFreqs)
    data2plot = groupAvgCoherencePlot(:,:,freq);
    data2plot = triu(data2plot);
    [dataR, dataC, data2plot] = find(data2plot);
    groupAvgCoherenceDist(:,freq) = data2plot;
    clear data2plot
end

%% run Friedman test to compare for differences between frequencies
clear pFried tblFried statsFried
[pFried, tblFried, statsFried] = friedman(groupAvgCoherenceDist,1,'off');
if pFried < 0.05
    cFried = multcompare(statsFried,'CType','bonferroni');
end
tblMultCompFried = array2table(cFried,"VariableNames", ...
    ["Group A","Group B","Lower Limit","A-B","Upper Limit","P-value"]);

%% then compare each condition against zero (i.e., significant increase in coherence)
clear p h stats
for freq = 1:length(vibrationFreqs)
    [p(freq,1),h(freq,1),stats(freq,1)] = signrank(groupAvgCoherenceDist(:,freq), 0, 'Alpha', 0.05, 'tail', 'right');
end
p_adj = min(p.*length(vibrationFreqs),1);

%% add a column to groupAvgCoherenceDist containing the pair IDs
pairIDs = (1:length(groupAvgCoherenceDist))';
groupAvgCoherenceDist = horzcat(pairIDs, groupAvgCoherenceDist);
% convert to table
tbl = array2table(groupAvgCoherenceDist,'VariableNames',{'PairID','TwoHz','SixHz','TwelveHz','TwentyHz','FortyHz'});

% save table to csv to import to R
writetable(tbl,['repeatMeasuresANOVA_data\groupLevel_regionSpecificTable_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.csv'])

%% plot group avg coherence matrices as traditional violin plot
figure();
violin(groupAvgCoherenceDist(:,2:6),1:5,'facecolor',colors(1:5,:),'facealpha',1,'edgecolor','','medc','');
ylim([-0.08 0.08])
xticks([1, 2, 3, 4, 5]); yticks([-0.08 -0.04 0 0.04 0.08]) 
xticklabels({'2 Hz','6 Hz','12 Hz','20 Hz','40 Hz'})
axis square; ax = gca; ax.FontSize = 12;
ylabel('MSC Change','FontSize',14)
title([freqName ' Coherence Changes'],'FontSize',14)
box off; set(gcf,'Position',[100 200 500 500])
saveas(gcf,['figures/coherence/GroupAvgCoherenceAllRegions_violin_' num2str(lLim) '-' num2str(uLim) 'Hz_v2.svg'])

%% identify coherence pairs at least two standard deviations above the mean
for curFreq = 1:length(vibrationFreqs)
    curMean = mean(groupAvgCoherenceDist(:,curFreq+1));
    curStd = std(groupAvgCoherenceDist(:,curFreq+1));
    threshold = curMean + (2*curStd);
    respPairs = find(groupAvgCoherenceDist(:,curFreq+1) >= threshold);
    respValues{curFreq,1} = groupAvgCoherenceDist(respPairs,curFreq+1);
    meanRespVal(curFreq,1) = mean(respValues{curFreq,1});

    % find regions for each pair
    respRegions = cell(length(respPairs),2);
    for i = 1:length(respPairs)
        respRegions{i,1} = uniqueElements{dataR(respPairs(i))};
        respRegions{i,2} = uniqueElements{dataC(respPairs(i))};
    end

    % chord plot showing connectivity
    connections = vibrotactile_taVNS_plotChordDiagrams(uniqueElements,groupAvgCoherencePlot,curFreq,threshold,7,...
        vibrationFreqs,lLim,uLim);
end

%% load in freesurfer-specific regions
freesurferData = importdata('FreeSurferColorLUT.lst');
freesurferLabels = freesurferData.textdata(:,2);
freesurferLabels_num = str2double(freesurferData.textdata(:,1));

%% load in corresponding freesurferLabels for each of uniqueElements
t = readtable('resortingGroups.xlsx','Sheet','element2freesurfer','Range','A1:I29'); 
t.Properties.VariableNames{1} = 'UniqIDs';
for i = 2:numel(t.Properties.VariableNames)
    t.Properties.VariableNames{i} = sprintf('fs_names_%s', num2str(i-1));
end

map_fsl_uniqIDs = zeros(size(t,1),size(t,2)-1);

% uniqIDnums represents the number of unique elements present across all subjects at the group level
for uniqIDnums = 1:size(t,1)  
    % extract all corresponding freesurfer labels for the given unique element, uniqIDnums (1 per each unique region)
    % column 1 in 't' is the list of unique elements, corresponding freesurfer labels start in column 2
    t_uniqID_a = table2array(t(uniqIDnums,2:end)); 
    
    % identify cells w non-empty str
    % uniqID_ind = find(t_uniqID_a ~= '');
    nonEmptyCells = ~cellfun(@isempty, t_uniqID_a);
    uniqID_ind = num2cell(find(nonEmptyCells));
    y = 1; 
    for fslabelnums = 1:numel(uniqID_ind)
        fslabel_ind = find(contains(freesurferLabels, t_uniqID_a{fslabelnums}));
        map_fsl_uniqIDs(uniqIDnums, y) = freesurferLabels_num(fslabel_ind);
        y = y+1;  
    end
end

%% read in generic brain atlas and freesurfer parcel outputs
atlas= Read4dfp('MNI152_711-2B_333.4dfp.img');
wmparc = Read4dfp('wmparc_on_MNI152_711-2B_333.4dfp.img'); % freesurfer parcel outputs 

[glmmask, frames, voxelsize] = read_4dfpimg_v1(['glm_atlas_mask_333.4dfp.img'],1,'littleendian');
wmparc_glm = wmparc(find(glmmask)); 
wmparc_uniqIds = zeros(numel(wmparc_glm),1);

% uniqIDnums represents the number of unique elements present across all subjects at the group level
for uniqIDnums = 1:size(t,1)  
    % find the unique indices for the given region
    fsl_labnum = unique(map_fsl_uniqIDs(uniqIDnums,:)); 
    % check where fsl_labnum = 0 and eliminate it
    fsl_labnum(fsl_labnum == 0) = [];
    
    ind = [];
    for n = 1:numel(fsl_labnum)
        ind = [ind; find(wmparc_glm == fsl_labnum(n))];
    end
    
    wmparc_uniqIds(ind) = uniqIDnums;
end

% plot all freesurfer parcellations included in analysis
MapOverlay(atlas, wmparc_uniqIds,'caxvals',[1 28],'cmapopt',"custom_28")
exportgraphics(gcf,['figures/freesurfer/allParcellations_v2.png'],'Resolution',900)

%% plot coherence to other brain regions for a selected seed and vibration frequency
seed = 'L-Amyg';
seedIdx = find(contains(uniqueElements,seed));
vibrationFreq = 4;
seedCoh = groupAvgCoherencePlot(seedIdx,:,vibrationFreq);

% visualize seed region only
seedOnly = seedCoh;
seedOnly(seedIdx) = -0.55;
seed_map_only = zeros(numel(wmparc_glm),1);
for i = 1:size(t,1)    
    seed_map_only(find(wmparc_uniqIds == i)) = seedOnly(i); 
end
% only show seed value
seed_map_only(abs(seed_map_only) < 0.55) = 0;
figure; MapOverlay(atlas, seed_map_only,'caxvals',[-1 1],'cmapopt',"purple_kara");

%% choose slice for showing seed region
figure; MapOverlay(atlas, seed_map_only,'caxvals',[-1 1],'cmapopt',"purple_kara",...
    'snapind',[15],'snapsize',[1,1]);
exportgraphics(gcf,['figures/freesurfer/seedRegion_' seed '_vibration' num2str(vibrationFreq) '_'...
    num2str(lLim) '-' num2str(uLim) 'Hz.png'],'Resolution',600)

% connectivity to seed region
seedCoh(seedIdx) = 0;
seed_map = zeros(numel(wmparc_glm),1);
for i = 1:size(t,1)    
    seed_map(find(wmparc_uniqIds == i)) = seedCoh(i); 
end

% only show values where coherence change is at least 0.01
seed_map(abs(seed_map) < 0.01) = 0;

% first plot all slices
figure; MapOverlay(atlas, seed_map,'caxvals',[-.05 .05],'cmapopt',"vibrant"); 

% choose specific slices to show
figure; MapOverlay(atlas, seed_map,'caxvals',[-.05 .05],'cmapopt',"vibrant", ...
    'snapind',[15, 20, 25, 30, 35],'snapsize',[1,5]); 
exportgraphics(gcf,['figures/freesurfer/selectedSlices_' seed '_vibration' num2str(vibrationFreq) '_'...
    num2str(lLim) '-' num2str(uLim) 'Hz_v2.png'],'Resolution',900)





