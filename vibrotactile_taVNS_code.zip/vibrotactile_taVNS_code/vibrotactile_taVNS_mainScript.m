% Kara Donovan: 7/15/2022
% main script for analysis of vibrotactile data
% function dependencies: vibrotactile_taVNS_epochData, vibrotactile_taVNS_computeCoherence, vibrotactile_taVNS_chkboard

clear;
clc;
% allSubjs = {'Subject001','Subject002','Subject003','Subject004','Subject005','Subject006','Subject007'};
allSubjs = {'BJH021','BJH024','BJH025','BJH026','BJH027','BJH029','BJH030'};

% download EEGLAB and add to path

for curSubj = 1:length(allSubjs)

% define parameters
subj = allSubjs{curSubj};
disp(subj)
condition = 'ear';
refType = 'car';
session = 1;
power = 'power'; % set to compute power, or just use envelope
colors = [66, 134, 137; 44, 78, 113; 181, 106, 84; 214, 139, 82; 157, 93, 129; 112, 70, 120; 0 105 54]./255; % custom colors

%% load in preprocessed data (not enveloped yet, to be used for timefreq plots)
% hard code path to data
experiment = load(['D:\sEEG_vibrotactileProjects\preprocessed_data\ear\car\'...
    subj '_' condition '_' refType '_session_1.mat']);
preprocessedData = experiment.preProcessedReRef.signal;
groups = experiment.preProcessedReRef.groups;

%% separate out 3 min baseline at start
stimCodeIdx = find(experiment.preProcessedReRef.stimulusCode ~= 0);
baselineEnd = stimCodeIdx(1)-1;
baselineSignal = preprocessedData(:,1:baselineEnd);

% break into epochs of 10001 samples
epochSize = 10001;
numEpochs = floor(length(baselineSignal)/epochSize);
epochedBaseline = NaN(size(baselineSignal,1),epochSize,numEpochs);

for i = 1:numEpochs
    epochStart = (i-1)*epochSize + 1;
    epochEnd = i*epochSize;
    epochedBaseline(:,:,i) = baselineSignal(:,epochStart:epochEnd);
end

%% load in envelope data (not epoched, same length as time series)
% hard code path to data
data = load(['D:\sEEG_vibrotactileProjects\envelope_data\' subj '_' condition '_' refType '_session_' ...
    num2str(session) 'timeSeriesEnvelopes_' power '.mat']);

% extract variables
sr = data.sr;
envelope = data.envelope;
power = data.power;
stimulusCodes1 ={'TwoHz', 'SixHz', 'TwelveHz', 'TwentyHz', 'FortyHz'};

clear data

%% epoch data at preprocessing stage
stimOnEpochs = vibrotactile_taVNS_epochData(experiment.preProcessedReRef.signal,experiment.preProcessedReRef.stimulusCode,...
    stimulusCodes1,0,5,sr);

%% sort groups and identify channels to exclude from future analysis
% sort groups
[groupsSorted, groupsIdx] = sort(groups);

% exclude white matter channels
wmChans = false(size(groupsSorted));
for i = 1:length(groupsSorted)
    if contains(groupsSorted{i}, 'WM') || contains(groupsSorted{i}, 'Vent') || contains(groupsSorted{i}, 'Unk')
        wmChans(i) = true; 
    end
end
wmChans = find(wmChans);
updatedGroups = groupsSorted;
updatedGroups(wmChans,:) = [];

%% NaN out trials with obvious ictal activity
ictalThreshold = 500;
% keep track of the number of bad trials for each channel
badTrials = zeros(size(stimOnEpochs.TwoHz,1),length(stimulusCodes1));
for physFreq = 1:length(stimulusCodes1)
    for chan = 1:size(stimOnEpochs.(stimulusCodes1{physFreq}),1)
        for t = 1:size(stimOnEpochs.(stimulusCodes1{physFreq}),3)
            if any(abs(stimOnEpochs.(stimulusCodes1{physFreq})(chan,:,t)) > ictalThreshold)
                stimOnEpochs.(stimulusCodes1{physFreq})(chan,:,t) = NaN;
                badTrials(chan,physFreq) = badTrials(chan,physFreq) + 1;
            end
        end
    end
end
reSortBadTrials = badTrials(groupsIdx,:);
reSortBadTrials(wmChans,:) = [];

%% check if there are any channels which are all bad trials (30) for one or more vibration conditions
badChans = any(reSortBadTrials(:) == 30);
if badChans == 1
    [badRow, badCol] = find(reSortBadTrials == 30);
end

%% baseline
% NaN out trials with obvious ictal activity
% keep track of the number of bad trials for each channel
badTrialsBaseline = zeros(size(epochedBaseline,1),1);
for chan = 1:size(epochedBaseline,1)
    for t = 1:size(epochedBaseline,3)
        if any(abs(epochedBaseline(chan,:,t)) > ictalThreshold)
            epochedBaseline(chan,:,t) = NaN;
            badTrialsBaseline(chan,1) = badTrialsBaseline(chan,1) + 1;
        end
    end
end
reSortBadTrialsBaseline = badTrialsBaseline(groupsIdx);
reSortBadTrialsBaseline(wmChans) = [];

%% check if there are any channels which are all bad trials (36) for baseline
badChansBaseline = any(reSortBadTrialsBaseline(:) == size(epochedBaseline,3));
if badChansBaseline == 1
    [badRowBaseline, badColBaseline] = find(reSortBadTrialsBaseline == size(epochedBaseline,3));
end

%% save matrices containing info on number of bad trials
save(['D:\sEEG_vibrotactileProjects\rejectedTrials\' subj '_' condition '_' refType '_session_'...
    num2str(session) '_badTrials.mat'],...
    'reSortBadTrials','reSortBadTrialsBaseline')

%% compute coherence matrices
lLim = 4; uLim = 8;

for physFreq = 1:length(stimulusCodes1)
    disp(stimulusCodes1{physFreq})
    current = stimOnEpochs.(stimulusCodes1{physFreq});
    reSortCurrent = current(groupsIdx,:,:);
    reSortCurrent(wmChans,:,:) = [];
    numChans = size(reSortCurrent,1);
    trials = size(reSortCurrent,3);
    newSR = 500;
    ws = newSR*2.5;    
    pOverlap = 0.7;
    cxy.(stimulusCodes1{physFreq}) = cell(trials, 1);

    % lowpass anti-aliasing filter
    lp_cutoff = 200;
    order = 5;
    type = 'low';
    [b0_lp, a0_lp] = butter(order, 2*lp_cutoff/sr, type);
    lp_signal = NaN(size(reSortCurrent));
    for t = 1:trials
        for c = 1:numChans
            % flag to check if that trial was NaN'd out
            if isnan(reSortCurrent(c,1,t))
                continue
            end
            lp_signal(c,:,t) = filtfilt(b0_lp,a0_lp,double(reSortCurrent(c,:,t)'))'; % note: have to be in samples x chans for filtfilt function
        end
    end
    
    % compute coherence
    cxyTemp = vibrotactile_taVNS_computeCoherence(lp_signal,lLim,uLim,numChans,trials,sr,newSR,ws,pOverlap,0);
    cxy.(stimulusCodes1{physFreq}) = cxyTemp;
    cxyStimOnTrials = cellfun(@(x) mean(x,2),cxyTemp,'UniformOutput',false);
    cxyStimOnTrials = horzcat(cxyStimOnTrials{:});
    t = tril(true(numChans),-1);
    cxyStimOnTrialsMat = cell(length(cxyTemp),1);
    for trial = 1:length(cxyTemp)
        cxyStimOnTrialsMat{trial,1} = zeros(numChans,numChans);
        cxyStimOnTrialsMat{trial,1}(t) = cxyStimOnTrials(:,trial);
        cxyStimOnTrialsMat{trial,1} = cxyStimOnTrialsMat{trial,1} + triu(cxyStimOnTrialsMat{trial,1}');
    end
    cxyStimOnTrialsMat = cat(3,cxyStimOnTrialsMat{:});
    cxyStimOnTrialsAllFreq.(stimulusCodes1{physFreq}) = cxyStimOnTrialsMat;
    clear cxyTemp cxyStimOnTrialsMat
end

% save stim on coherences for group analysis on ROIs
save(['D:\sEEG_vibrotactileProjects\coherenceData\globalCoherences\' subj '_' condition '_' refType ...
    '_session_' num2str(session) '_stimOn_lLim' num2str(lLim) '_uLim' num2str(uLim)...
    '.mat'],'cxy','cxyStimOnTrialsAllFreq','stimulusCodes1','groupsSorted','groupsIdx','wmChans','-v7.3')

%% Compute mean coherence
for physFreq = 1:length(stimulusCodes1)
    coherenceEpochs.(stimulusCodes1{physFreq}) = squeeze(mean(cat(3,cxy.(stimulusCodes1{physFreq}){:}),2,'omitnan'));
    coherenceAvg.(stimulusCodes1{physFreq}) = zeros(numChans, numChans); 
    t = tril(true(numChans),-1); 
    coherenceAvg.(stimulusCodes1{physFreq})(t) = mean(mean(cat(3,cxy.(stimulusCodes1{physFreq}){:}),3,'omitnan'),2,'omitnan');
    coherenceAvg.(stimulusCodes1{physFreq}) = coherenceAvg.(stimulusCodes1{physFreq}) + triu(coherenceAvg.(stimulusCodes1{physFreq})');
end

%% Compute coherence matrices - baseline
reSortBaseline = epochedBaseline(groupsIdx,:,:);
reSortBaseline(wmChans,:,:) = [];
% lowpass anti-aliasing filter
lp_signal_baseline = NaN(size(reSortBaseline));
for t = 1:size(reSortBaseline,3)
    for c = 1:numChans
        % flag to check if that trial was NaN'd out
        if isnan(reSortBaseline(c,1,t))
            continue
        end
        % note: have to be in samples x chans for filtfilt function
        lp_signal_baseline(c,:,t) = filtfilt(b0_lp,a0_lp,double(reSortBaseline(c,:,t)'))'; 
    end
end
% compute coherence
cxyBaseline = vibrotactile_taVNS_computeCoherence(lp_signal_baseline,lLim,uLim,numChans,size(lp_signal_baseline,3),...
    sr,newSR,ws,pOverlap,0);

cxyBaselineTrials = cellfun(@(x) mean(x, 2), cxyBaseline, 'UniformOutput', false);
cxyBaselineTrials = horzcat(cxyBaselineTrials{:});
t = tril(true(numChans),-1); 
cxyBaselineTrialsMat = cell(length(cxyBaseline),1);
for trial = 1:length(cxyBaseline)
    cxyBaselineTrialsMat{trial,1} = zeros(numChans,numChans);
    cxyBaselineTrialsMat{trial,1}(t) = cxyBaselineTrials(:, trial);
    cxyBaselineTrialsMat{trial,1} = cxyBaselineTrialsMat{trial,1} + triu(cxyBaselineTrialsMat{trial,1}');
end
cxyBaselineTrialsMat = cat(3,cxyBaselineTrialsMat{:});

% save stim on coherences for group analysis on ROIs - baseline
save(['coherenceData/globalCoherences/' subj '_' condition '_' refType '_session_' num2str(session) '_baseline_lLim'...
    num2str(lLim) '_uLim' num2str(uLim) '.mat'],'cxyBaseline','cxyBaselineTrialsMat','stimulusCodes1',...
    'groupsSorted','groupsIdx','wmChans')

%% compute average coherence across all pairs 
% cxy contains a cell for each vibrotactile frequency, and each of those cells contains a 30x1 cell array 
% (30 cells = 30 trials at that vibrotactile frequency) -- within each of
% those 30 cells, format is # pairs x # frequencies being computed

% average across all pairs
% Initialize 3D matrix for avg global coherence estimates
avgGlobalCoherence = NaN(trials,length(lLim:uLim),length(stimulusCodes1));
avgBaselineGlobalCoherence = NaN(length(cxyBaseline),length(lLim:uLim));

% loop over each vibrotactile frequency
for physFreq = 1:length(stimulusCodes1)
    % Compute the row-wise average for each cell: stim on
    for i = 1:trials
        avgGlobalCoherence(i,:,physFreq) = mean(cxy.(stimulusCodes1{physFreq}){i},'omitnan');
    end
end
% Compute the row-wise average for each cell: baseline
for i = 1:length(cxyBaseline)
    avgBaselineGlobalCoherence(i,:) = mean(cxyBaseline{i},'omitnan');
end

%% Compute mean coherence - baseline
coherenceAvgBaseline = zeros(numChans, numChans); 
t = tril(true(numChans),-1); 
coherenceAvgBaseline(t) = mean(mean(cat(3, cxyBaseline{:}),3,'omitnan'),2,'omitnan');
coherenceAvgBaseline = coherenceAvgBaseline + triu(coherenceAvgBaseline');

% save baseline coherence avg and corresponding labels
save(['coherenceData/baselineAverages/' subj '_baseline_lLim' num2str(lLim) '_uLim' num2str(uLim) '.mat'],...
    'updatedGroups','coherenceAvgBaseline')

%% prepare labels for each grouping
% start indices
clear groupChange
groupsSorted(wmChans) = [];
startIdx = ones(length(groupsSorted),1);
currentElement = groupsSorted{1};
for i = 2:length(groupsSorted)
    if ~strcmp(groupsSorted{i}, currentElement)
        startIdx(i) = i;
        currentElement = groupsSorted{i};
    else
        startIdx(i) = startIdx(i-1);
    end
end
idx = find(~strcmp(groupsSorted(1:end-1),groupsSorted(2:end))) + 1;
startIdx(idx) = idx;

% stop indices
d = ~strcmp(groupsSorted(1:end-1),groupsSorted(2:end));
stopIdx = find(d);
stopIdx(end+1) = length(groupsSorted);

% range
groupChange(:,1) = unique(startIdx);
groupChange(:,2) = stopIdx;
clustLen = groupChange(:,2) - groupChange(:,1) + 1;

% median for each range
medLabels = median(groupChange,2);

% unique labels
uniqueLabels = unique(groupsSorted);

%% find where the changeover from left to right occurs
% extract the first character of each string
firstChar = cellfun(@(s) s(1), groupsSorted);

% Find the unique first characters
uniqueFirstChar = unique(firstChar);

% right hemisphere
rightHem = find(firstChar == 'R');
rightHem = rightHem(1);

%% baseline coherence matrices reduced to unique regions (1 matrix/trial)
intraNCBaselineTrials = NaN(length(cxyBaseline),length(uniqueLabels));
interNCBaselineTrials = NaN(length(uniqueLabels),length(uniqueLabels),length(cxyBaseline));
newmatBaselineTrials = NaN(numChans,numChans,length(cxyBaseline));
for trial = 1:length(cxyBaseline)
    [intraNC, interNC, newmat] = vibrotactile_taVNS_chkboard(cxyBaselineTrialsMat(:,:,trial), clustLen);
    for c = 1:length(intraNC.mean)
        interNC.mean(c,c) = intraNC.mean(c);
    end
    intraNCBaselineTrials(trial,:) = intraNC.mean;
    interNCBaselineTrials(:,:,trial) = interNC.mean;
    newmatBaselineTrials(:,:,trial) = newmat;
end

% vectorize the region x region baseline coherence matrices
for trial = 1:length(cxyBaseline)
    curTrial = interNCBaselineTrials(:,:,trial);
    vectorizedInterNCBaseline(:,trial) = curTrial(triu(true(size(curTrial))));
end

%% stim on coherence matrices reduced to unique regions (1 matrix/trial)
for physFreq = 1:length(stimulusCodes1)
    intraNCStimOnTrials.(stimulusCodes1{physFreq}) = NaN(trials,length(uniqueLabels));
    interNCStimOnTrials.(stimulusCodes1{physFreq}) = NaN(length(uniqueLabels),length(uniqueLabels),trials);
    newmatStimOnTrials.(stimulusCodes1{physFreq}) = NaN(numChans,numChans,trials);
    for trial = 1:trials
        [intraNC, interNC, newmat] = vibrotactile_taVNS_chkboard(cxyStimOnTrialsAllFreq.(stimulusCodes1{physFreq})(:,:,trial),...
            clustLen);
        for c = 1:length(intraNC.mean)
            interNC.mean(c,c) = intraNC.mean(c);
        end
        intraNCStimOnTrials.(stimulusCodes1{physFreq})(trial,:) = intraNC.mean;
        interNCStimOnTrials.(stimulusCodes1{physFreq})(:,:,trial) = interNC.mean;
        newmatStimOnTrials.(stimulusCodes1{physFreq})(:,:,trial) = newmat;
    end
end

% vectorize the region x region stim on coherence matrices
for physFreq = 1:length(stimulusCodes1)
    for trial = 1:trials
        curTrial = interNCStimOnTrials.(stimulusCodes1{physFreq})(:,:,trial);
        vectorizedInterNCAllFreq.(stimulusCodes1{physFreq})(:,trial) = curTrial(triu(true(size(curTrial))));
    end
end

%% generate indices for which regions are in each pair
numRegions = length(clustLen);
% initialize empty vectors
element1 = [];
element2 = [];
% iterate to generate each element in the pair
for i = 1:numRegions
    % generate a sequence from 1 to current value 'i' and append to vector
    sequence = 1:i;
    element1 = [element1, sequence];
    % repeat current value 'i' times and append to vector
    element2 = [element2, repmat(i,1,i)];
end
% store corresponding regions for each element
vectorizedRegions = cell(2,length(element1));
for i = 1:length(element1)
    vectorizedRegions{1,i} = uniqueLabels{element1(i)};
    vectorizedRegions{2,i} = uniqueLabels{element2(i)};
end

%% compute difference in distributions (baseline vs. stim on) for each pair
ranksum_pval = NaN(length(vectorizedInterNCBaseline),length(stimulusCodes1));
for physFreq = 1:length(stimulusCodes1)
    cohenD = NaN(length(vectorizedInterNCBaseline),1);
    for pair = 1:length(vectorizedInterNCBaseline)
        group1 = vectorizedInterNCBaseline(pair,:);
        group2 = vectorizedInterNCAllFreq.(stimulusCodes1{physFreq})(pair,:);
        % Compute Cohen's d
        meanDiff = mean(group2,'omitnan') - mean(group1,'omitnan');  % Mean difference
        if isnan(meanDiff)
            continue
        end
        pooledStd = sqrt((std(group1,'omitnan')^2 + std(group2,'omitnan')^2) / 2);  % Pooled standard deviation
        cohenD(pair,1) = meanDiff / pooledStd;  % Cohen's d
        % Run Wilcoxon rank sum test
        ranksum_pval(pair,physFreq) = ranksum(group1, group2, 'alpha', 0.025, 'tail', 'left');
    end
    subplot(2,3,physFreq);
    cohenDplot = sort(cohenD);
    cohenDplot = cohenDplot(cohenDplot > 0.2);
    percentRespPairs(physFreq,1) = (length(cohenDplot)/length(vectorizedInterNCBaseline))*100;
    barh(cohenDplot); box off
    histogram(cohenD,'BinWidth',0.05)
    box off; hold on
    xline(0.2,'LineWidth',1.5)
    xlim([-1 1]);ylim([0 30])
    title(stimulusCodes1{physFreq})
end

%% baseline subtraction coherence matrices
% initialize cell arrays to store average coherence values reduced to unique regions (1 cell/vibrotactile frequency)
intraNCAllFreq = cell(length(stimulusCodes1),1);
interNCAllFreq = cell(length(stimulusCodes1),1);
newmatAllFreq = cell(length(stimulusCodes1),1);
figure();
for physFreq = 1:length(stimulusCodes1)
    matDif = coherenceAvg.(stimulusCodes1{physFreq})-coherenceAvgBaseline;
    % check if matDif contains any NaN values
    any(isnan(matDif(:)));
    
    % store average values for each region x region comparison
    [intraNC, interNC, newmat] = chkboard(matDif, clustLen);
    for c = 1:length(intraNC.mean)
        interNC.mean(c,c) = intraNC.mean(c);
    end
    intraNCAllFreq{physFreq,1} = intraNC;
    interNCAllFreq{physFreq,1} = interNC;
    newmatAllFreq{physFreq,1} = newmat;
    
    subplot(2,3,physFreq)
    imagesc(newmat,[-.1 .1]); axis square
    clear intraNC interNC newmat
    hold on
    xline(groupChange(2:end,1)-0.5,'--'); yline(groupChange(2:end,1)-0.5,'--')
    xline(rightHem-0.5,'LineWidth',1.5); yline(rightHem-0.5,'LineWidth',1.5);
    colormap(brewermap([],'*RdBu')); c = colorbar;
    if physFreq == 1
        cLabel = ylabel(c,'MSC (Baseline Subtraction'); set(cLabel,'Rotation',270,'FontSize',10); cLabel.Position(1) = 3.5;
    end
    title(stimulusCodes1{physFreq},'FontSize',14)
end
set(gcf,'position',[100 50 1300 800])
saveas(gcf,['figures/coherence/' subj '_' condition '_' refType ...
    '_anatomicalGroups_stimOn-baseline_' num2str(lLim) '-' num2str(uLim) 'HzCoherence.svg'])

% also save baseline matrices for additional analysis
[intraNC_base, interNC_base, newmat_base] = chkboard(coherenceAvgBaseline, clustLen);
for c = 1:length(intraNC_base.mean)
    interNC_base.mean(c,c) = intraNC_base.mean(c);
end
figure();
subplot(2,3,1)
imagesc(newmat_base,[0.1 0.6]); axis square
hold on
xline(groupChange(2:end,1)-0.5,'--'); yline(groupChange(2:end,1)-0.5,'--')
xline(rightHem-0.5,'LineWidth',1.5); yline(rightHem-0.5,'LineWidth',1.5);
colormap(brewermap([],'Greens')); c = colorbar;
cLabel = ylabel(c,'Baseline MSC'); set(cLabel,'Rotation',270,'FontSize',10); cLabel.Position(1) = 3.5;
saveas(gcf,['figures/coherence/' subj '_' condition '_' refType ...
    '_anatomicalGroups_baseline_' num2str(lLim) '-' num2str(uLim) 'HzCoherence.svg'])

% save average values for region x region comparisons
save(['coherenceData/regionAverages/' subj '_' condition '_' refType '_session_' num2str(session) '_avgCoherence_'...
    num2str(lLim) '-' num2str(uLim) '.mat'],'intraNCAllFreq','interNCAllFreq','newmatAllFreq',...
    'intraNC_base','interNC_base','newmat_base','uniqueLabels','percentRespPairs')

end
