function [connections] = vibrotactile_taVNS_plotChordDiagrams(uniqueElements,groupAvgCoherencePlot,curFreq,threshold,...
    upperBound,vibrationFreqs,lLim,uLim)
    % upperBound is the max line width for scaling
    % manually resort the order of pairings
    resortIdx = [17 22 18 16 21 23 25 11 8 6 1 3 7 15 2 5 12 10 14 4 13 9 27 19 28 24 26 20]';
    % create a new cell array for reordered elements
    reorderedGroups = cell(size(uniqueElements));
    % iterate through the new order of indices
    for i = 1:numel(resortIdx)
        reorderedGroups{i} = uniqueElements{resortIdx(i)};
    end
    connections(:,1:2) = nchoosek(1:length(uniqueElements),2);

    for c = 1:length(connections)
        % column 3 of connections is the coherence change between those 2 regions --> 
        % this value is used to scale the line width on the chord diagram
        connections(c,3) = groupAvgCoherencePlot(connections(c,1),connections(c,2),curFreq);
        % column 4 of connections represents whether the coherence change is an increase or decrease 
        if connections(c,3) < 0
            connections(c,4) = -1;
        else
            connections(c,4) = 1;
        end
        % only plot connections exceeding a set threshold
        if connections(c,3) < threshold
            connections(c,3) = 0; % connections with a change of 0 get skipped
        end
    end
    % multiply by 100 to aid in scaling of line width
    connections(:,3) = 100*(connections(:,3));
    % find indices of nonzero elements
    indices = find(connections(:,3) ~= 0);
    % extract the nonzero elements
    nonzeroElements = connections(indices,3);
    % find minimum and maximum of nonzero elements
    minValue = min(nonzeroElements);
    maxValue = max(nonzeroElements);
    % rescale the nonzero elements
    rescaledNonzeroElements = ((nonzeroElements - minValue)/(maxValue - minValue)) * (upperBound-1) + 1;
    % create a vector of the same size as the original vector with zero values
    rescaledVector = zeros(size(connections(:,3)));
    % assign the rescaled nonzero elements back to their respective positions in the vector
    rescaledVector(indices) = rescaledNonzeroElements;
    % replace the third column in connections with the rescaled vector
    connections(:,3) = rescaledVector;
    % update nodes based on resorting of groups
    for c = 1:length(connections)
        tempNode1 = connections(c,1);
        tempNode2 = connections(c,2);
        connections(c,1) = find(resortIdx == tempNode1);
        connections(c,2) = find(resortIdx == tempNode2);
    end
    % convert from matrix to table
    connectionsT = array2table(connections);
    % generate chord diagram
    chordPlot(reorderedGroups,connectionsT);
    set(gcf,'Position',[400 200 600 600]) % [a b W L] where a,b is position of lower left corner of figure
    % save figure
    saveas(gcf,['figures/coherence/GroupAvgCoherenceRespPairs_' vibrationFreqs{curFreq} 'vibration_' ...
        num2str(lLim) '-' num2str(uLim) 'Hz_v2.pdf'])
end






